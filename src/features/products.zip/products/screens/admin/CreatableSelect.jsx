import { useState, useRef, useEffect } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Paper from '@mui/material/Paper';
import CircularProgress from '@mui/material/CircularProgress';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import CheckIcon from '@mui/icons-material/Check';

export default function CreatableSelect({
  label,
  options = [],
  value,
  onChange,
  onCreate,
  error,
  helperText,
  size = 'small',
  placeholder = 'Select or type to add new…',
  creating = false,
}) {
  const [open, setOpen]       = useState(false);
  const [inputVal, setInputVal] = useState('');
  const containerRef           = useRef(null);

  const selectedLabel = options.find((o) => String(o.value) === String(value))?.label ?? '';

  useEffect(() => {
    if (open) setInputVal('');
  }, [open]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filtered = inputVal.trim()
    ? options.filter((o) => o.label.toLowerCase().includes(inputVal.toLowerCase()))
    : options;

  const exactMatch = options.some(
    (o) => o.label.toLowerCase() === inputVal.trim().toLowerCase()
  );

  const showCreateOption = inputVal.trim().length > 0 && !exactMatch;

  const handleSelect = (option) => {
    onChange(option.value);
    setOpen(false);
  };

  const handleCreate = () => {
    if (!inputVal.trim() || creating) return;
    onCreate(inputVal.trim());
    setOpen(false);
    setInputVal('');
  };

  return (
    <Box ref={containerRef} sx={{ position: 'relative' }}>
      <TextField
        label={label}
        size={size}
        fullWidth
        value={open ? inputVal : selectedLabel}
        placeholder={open ? placeholder : undefined}
        error={error}
        helperText={helperText}
        onClick={() => setOpen(true)}
        onChange={(e) => { setInputVal(e.target.value); if (!open) setOpen(true); }}
        slotProps={{
          input: {
            endAdornment: creating ? (
              <CircularProgress size={14} sx={{ color: 'primary.main', mr: 1 }} />
            ) : null,
          },
        }}
        sx={{
          '& .MuiOutlinedInput-root': {
            cursor: 'pointer',
            borderColor: error ? 'error.main' : undefined,
          },
        }}
      />

      {open && (
        <Paper
          elevation={4}
          sx={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            zIndex: 1400,
            mt: 0.5,
            borderRadius: 2,
            maxHeight: 220,
            overflowY: 'auto',
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          {filtered.length === 0 && !showCreateOption && (
            <Box sx={{ px: 2, py: 1.5 }}>
              <Typography variant="caption" color="text.secondary">
                No options found
              </Typography>
            </Box>
          )}

          {filtered.map((option) => (
            <Box
              key={option.value}
              onClick={() => handleSelect(option)}
              sx={{
                px: 2, py: 1.2, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                bgcolor: String(option.value) === String(value) ? 'action.selected' : 'transparent',
                '&:hover': { bgcolor: 'action.hover' },
              }}
            >
              <Typography variant="body2">{option.label}</Typography>
              {String(option.value) === String(value) && (
                <CheckIcon sx={{ fontSize: 14, color: 'primary.main' }} />
              )}
            </Box>
          ))}

          {showCreateOption && (
            <Box
              onClick={handleCreate}
              sx={{
                px: 2, py: 1.2, cursor: creating ? 'default' : 'pointer',
                display: 'flex', alignItems: 'center', gap: 1,
                borderTop: filtered.length > 0 ? '1px solid' : 'none',
                borderColor: 'divider',
                bgcolor: 'transparent',
                '&:hover': { bgcolor: '#fce4ec' },
              }}
            >
              {creating ? (
                <CircularProgress size={14} sx={{ color: 'primary.main' }} />
              ) : (
                <AddCircleOutlineIcon sx={{ fontSize: 16, color: 'primary.main' }} />
              )}
              <Typography variant="body2" sx={{ color: 'primary.main', fontWeight: 600 }}>
                {creating ? 'Creating…' : `Add "${inputVal.trim()}"`}
              </Typography>
            </Box>
          )}
        </Paper>
      )}
    </Box>
  );
}
